package com.example.projectstack.model

data class Project(
    val name: String = "",
    val description: String = "",
    val startDate: String = "",
    val endDate: String = "",
    val status: ProjectStatus = ProjectStatus.ONGOING,
    val students: List<Student> = emptyList(),
    val developers: List<Developer> = emptyList()
)

enum class ProjectStatus {
    ONGOING,
    COMPLETED
}
