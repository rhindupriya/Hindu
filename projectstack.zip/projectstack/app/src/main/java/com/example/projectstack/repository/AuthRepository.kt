package com.example.projectstack.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import com.example.projectstack.model.User
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class AuthRepository {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()

    suspend fun login(email: String, password: String): Result<User> = runCatching {
        val authResult = auth.signInWithEmailAndPassword(email, password).await()
        val uid = authResult.user?.uid ?: throw Exception("Authentication failed")
        
        val userDoc = firestore.collection("users").document(uid).get().await()
        when (userDoc.getString("role")) {
            "student" -> userDoc.toObject(User.Student::class.java)
            "developer" -> userDoc.toObject(User.Developer::class.java)
            "admin" -> userDoc.toObject(User.Admin::class.java)
            else -> throw Exception("Invalid user role")
        } ?: throw Exception("User data not found")
    }

    suspend fun registerStudent(student: User.Student, password: String): Result<Unit> = runCatching {
        val authResult = auth.createUserWithEmailAndPassword(student.email, password).await()
        val uid = authResult.user?.uid ?: throw Exception("Registration failed")
        
        firestore.collection("users").document(uid).set(student).await()
    }

    suspend fun registerDeveloper(developer: User.Developer, password: String): Result<Unit> = runCatching {
        val authResult = auth.createUserWithEmailAndPassword(developer.email, password).await()
        val uid = authResult.user?.uid ?: throw Exception("Registration failed")
        
        firestore.collection("users").document(uid).set(developer).await()
    }

    fun getCurrentUser(): Flow<User?> = flow {
        val uid = auth.currentUser?.uid
        if (uid != null) {
            val userDoc = firestore.collection("users").document(uid).get().await()
            val user = when (userDoc.getString("role")) {
                "student" -> userDoc.toObject(User.Student::class.java)
                "developer" -> userDoc.toObject(User.Developer::class.java)
                "admin" -> userDoc.toObject(User.Admin::class.java)
                else -> null
            }
            emit(user)
        } else {
            emit(null)
        }
    }

    fun logout() {
        auth.signOut()
    }
}
