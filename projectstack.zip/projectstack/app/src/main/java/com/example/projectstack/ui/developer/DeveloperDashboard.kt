package com.example.projectstack.ui.developer

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.projectstack.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeveloperDashboard() {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Attendance", "Tasks", "Projects", "Leave", "Profile")

    // Sample data
    val students = remember {
        listOf(
            Student(
                registrationNumber = "12345",
                name = "John Doe",
                batch = "2024",
                department = "Computer Science"
            ),
            Student(
                registrationNumber = "12346",
                name = "Jane Smith",
                batch = "2024",
                department = "Computer Science"
            )
        )
    }

    val tasks = remember {
        listOf(
            Task(
                title = "Design UI Mockups",
                description = "Create UI mockups for the app",
                deadline = "15/01/2025"
            ),
            Task(
                title = "Implement Login Screen",
                description = "Create login screen using Compose",
                deadline = "20/01/2025"
            )
        )
    }

    val projects = remember {
        listOf(
            Project(
                name = "Android App Development",
                description = "Building a project management app",
                startDate = "01/01/2025",
                endDate = "31/03/2025"
            ),
            Project(
                name = "Web Development",
                description = "Creating a responsive website",
                startDate = "01/02/2025",
                endDate = "30/04/2025"
            )
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Developer Dashboard") }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            TabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title) }
                    )
                }
            }

            when (selectedTab) {
                0 -> AttendanceTab(students)
                1 -> TasksTab(tasks)
                2 -> ProjectsTab(projects)
                3 -> LeaveTab()
                4 -> ProfileTab()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceTab(students: List<Student>) {
    var selectedDate by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = selectedDate,
            onValueChange = { selectedDate = it },
            label = { Text("Select Date (DD/MM/YYYY)") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(students) { student ->
                Card(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = student.name,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "Reg: ${student.registrationNumber}",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                text = "${student.batch} - ${student.department}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Switch(
                            checked = false,
                            onCheckedChange = { }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = { /* Save attendance */ },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text("Save Attendance")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TasksTab(tasks: List<Task>) {
    var showAddTask by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Button(
            onClick = { showAddTask = true },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Add New Task")
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(tasks) { task ->
                Card(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = task.title,
                            style = MaterialTheme.typography.titleLarge
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = task.description,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Deadline: ${task.deadline}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "Status: ${task.status}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }

    if (showAddTask) {
        AlertDialog(
            onDismissRequest = { showAddTask = false },
            title = { Text("Add New Task") },
            text = {
                Column {
                    OutlinedTextField(
                        value = "",
                        onValueChange = { },
                        label = { Text("Title") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = "",
                        onValueChange = { },
                        label = { Text("Description") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = "",
                        onValueChange = { },
                        label = { Text("Deadline") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showAddTask = false }) {
                    Text("Add Task")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTask = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun ProjectsTab(projects: List<Project>) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(projects) { project ->
            ProjectCard(project)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectCard(project: Project) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = project.name,
                style = MaterialTheme.typography.titleLarge
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = project.description,
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Start: ${project.startDate}",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    text = "End: ${project.endDate}",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Text(
                text = "Status: ${project.status}",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeaveTab() {
    var fromDate by remember { mutableStateOf("") }
    var toDate by remember { mutableStateOf("") }
    var numberOfDays by remember { mutableStateOf("") }
    var selectedLeaveType by remember { mutableStateOf(LeaveType.CASUAL) }
    var reason by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Apply Leave",
            style = MaterialTheme.typography.headlineMedium
        )

        OutlinedTextField(
            value = fromDate,
            onValueChange = { fromDate = it },
            label = { Text("From Date (DD/MM/YYYY)") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = toDate,
            onValueChange = { toDate = it },
            label = { Text("To Date (DD/MM/YYYY)") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = numberOfDays,
            onValueChange = { numberOfDays = it },
            label = { Text("Number of Days") },
            modifier = Modifier.fillMaxWidth()
        )

        Column {
            Text(
                text = "Leave Type",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            LeaveType.values().forEach { leaveType ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selectedLeaveType == leaveType,
                        onClick = { selectedLeaveType = leaveType }
                    )
                    Text(
                        text = leaveType.name,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            }
        }

        OutlinedTextField(
            value = reason,
            onValueChange = { reason = it },
            label = { Text("Reason") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )

        Button(
            onClick = { /* Apply leave */ },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text("Apply Leave")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileTab() {
    var developer by remember {
        mutableStateOf(
            Developer(
                employeeId = "EMP123",
                name = "John Developer",
                email = "john.dev@example.com",
                mobileNumber = "1234567890",
                designation = "Senior Developer",
                techStack = listOf("Android", "Kotlin", "Compose"),
                experience = "5 years",
                linkedInProfile = "linkedin.com/in/johndev",
                portfolioLink = "github.com/johndev",
                dateOfJoining = "01/01/2020"
            )
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Profile",
                style = MaterialTheme.typography.headlineMedium
            )
        }

        item {
            OutlinedTextField(
                value = developer.employeeId,
                onValueChange = { },
                label = { Text("Employee ID") },
                modifier = Modifier.fillMaxWidth(),
                enabled = false
            )
        }

        item {
            OutlinedTextField(
                value = developer.name,
                onValueChange = { },
                label = { Text("Name") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = developer.email,
                onValueChange = { },
                label = { Text("Email") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = developer.mobileNumber,
                onValueChange = { },
                label = { Text("Mobile Number") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = developer.designation,
                onValueChange = { },
                label = { Text("Designation") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = developer.techStack.joinToString(", "),
                onValueChange = { },
                label = { Text("Tech Stack") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = developer.experience,
                onValueChange = { },
                label = { Text("Experience") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = developer.linkedInProfile,
                onValueChange = { },
                label = { Text("LinkedIn Profile") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = developer.portfolioLink,
                onValueChange = { },
                label = { Text("Portfolio Link") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = developer.dateOfJoining,
                onValueChange = { },
                label = { Text("Date of Joining") },
                modifier = Modifier.fillMaxWidth(),
                enabled = false
            )
        }

        item {
            Button(
                onClick = { /* Update profile */ },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Text("Update Profile")
            }
        }
    }
}
