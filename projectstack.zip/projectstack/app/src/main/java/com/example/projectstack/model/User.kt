package com.example.projectstack.model

enum class UserRole {
    STUDENT,
    DEVELOPER,
    ADMIN
}

data class Student(
    val registrationNumber: String = "",
    val name: String = "",
    val email: String = "",
    val mobileNumber: String = "",
    val mentorName: String = "",
    val mentorMobile: String = "",
    val batch: String = "",
    val department: String = ""
)

data class Developer(
    val employeeId: String = "",
    val name: String = "",
    val email: String = "",
    val mobileNumber: String = "",
    val designation: String = "",
    val techStack: List<String> = emptyList(),
    val experience: String = "",
    val linkedInProfile: String = "",
    val portfolioLink: String = "",
    val dateOfJoining: String = ""
)

data class Admin(
    val name: String = "",
    val email: String = ""
)
