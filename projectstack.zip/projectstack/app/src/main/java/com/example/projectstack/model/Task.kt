package com.example.projectstack.model

data class Task(
    val title: String = "",
    val description: String = "",
    val deadline: String = "",
    val status: TaskStatus = TaskStatus.PENDING,
    val project: Project? = null,
    val assignedTo: Student? = null,
    val assignedBy: Developer? = null
)

enum class TaskStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED
}
