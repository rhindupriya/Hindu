package com.example.projectstack.model

data class Leave(
    val developer: Developer,
    val fromDate: String = "",
    val toDate: String = "",
    val numberOfDays: Int = 0,
    val leaveType: LeaveType = LeaveType.CASUAL,
    val reason: String = "",
    val status: LeaveStatus = LeaveStatus.PENDING
)

enum class LeaveType {
    SICK,
    CASUAL,
    VACATION
}

enum class LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED
}
