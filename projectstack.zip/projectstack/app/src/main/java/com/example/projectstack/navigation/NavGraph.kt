package com.example.projectstack.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.projectstack.ui.login.LoginScreen
import com.example.projectstack.ui.student.StudentDashboard
import com.example.projectstack.ui.developer.DeveloperDashboard
import com.example.projectstack.ui.admin.AdminPanel
import com.example.projectstack.model.UserRole

sealed class Screen(val route: String) {
    object Login : Screen("login")
    object StudentDashboard : Screen("student_dashboard")
    object DeveloperDashboard : Screen("developer_dashboard")
    object AdminPanel : Screen("admin_panel")
}

@Composable
fun NavGraph(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Screen.Login.route
    ) {
        composable(Screen.Login.route) {
            LoginScreen(
                onNavigate = { role ->
                    val route = when (role) {
                        UserRole.STUDENT -> Screen.StudentDashboard.route
                        UserRole.DEVELOPER -> Screen.DeveloperDashboard.route
                        UserRole.ADMIN -> Screen.AdminPanel.route
                    }
                    navController.navigate(route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                }
            )
        }
        
        composable(Screen.StudentDashboard.route) {
            StudentDashboard()
        }
        
        composable(Screen.DeveloperDashboard.route) {
            DeveloperDashboard()
        }
        
        composable(Screen.AdminPanel.route) {
            AdminPanel()
        }
    }
}
