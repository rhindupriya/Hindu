package com.example.projectstack.ui.login

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.projectstack.model.UserRole

class LoginViewModel : ViewModel() {
    var selectedRole by mutableStateOf<UserRole?>(null)
        private set

    fun updateRole(role: UserRole) {
        selectedRole = role
    }
}
