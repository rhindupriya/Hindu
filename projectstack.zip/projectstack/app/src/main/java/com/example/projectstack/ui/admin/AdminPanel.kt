package com.example.projectstack.ui.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.projectstack.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanel() {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Students", "Developers", "Projects", "Tasks", "Attendance", "Leaves", "Profile")

    // Sample data
    val students = remember {
        listOf(
            Student(
                registrationNumber = "12345",
                name = "John Doe",
                email = "john@example.com",
                mobileNumber = "1234567890",
                batch = "2024",
                department = "Computer Science"
            ),
            Student(
                registrationNumber = "12346",
                name = "Jane Smith",
                email = "jane@example.com",
                mobileNumber = "0987654321",
                batch = "2024",
                department = "Computer Science"
            )
        )
    }

    val developers = remember {
        listOf(
            Developer(
                employeeId = "EMP123",
                name = "John Developer",
                email = "john.dev@example.com",
                mobileNumber = "1234567890",
                designation = "Senior Developer",
                techStack = listOf("Android", "Kotlin", "Compose")
            ),
            Developer(
                employeeId = "EMP124",
                name = "Jane Developer",
                email = "jane.dev@example.com",
                mobileNumber = "0987654321",
                designation = "Junior Developer",
                techStack = listOf("Web", "React", "Node.js")
            )
        )
    }

    val projects = remember {
        listOf(
            Project(
                name = "Android App Development",
                description = "Building a project management app",
                startDate = "01/01/2025",
                endDate = "31/03/2025"
            ),
            Project(
                name = "Web Development",
                description = "Creating a responsive website",
                startDate = "01/02/2025",
                endDate = "30/04/2025"
            )
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Admin Panel") }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            ScrollableTabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title) }
                    )
                }
            }

            when (selectedTab) {
                0 -> StudentsTab(students)
                1 -> DevelopersTab(developers)
                2 -> ProjectsTab(projects)
                3 -> TasksTab()
                4 -> AttendanceTab()
                5 -> LeavesTab()
                6 -> AdminProfileTab()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentsTab(students: List<Student>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Manage Students",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(students) { student ->
                Card(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = student.name,
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "Reg: ${student.registrationNumber}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "Email: ${student.email}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "Mobile: ${student.mobileNumber}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "${student.batch} - ${student.department}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { /* Edit student */ }) {
                                Text("Edit")
                            }
                            TextButton(onClick = { /* Delete student */ }) {
                                Text("Delete")
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DevelopersTab(developers: List<Developer>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Manage Developers",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(developers) { developer ->
                Card(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = developer.name,
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "ID: ${developer.employeeId}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "Email: ${developer.email}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "Mobile: ${developer.mobileNumber}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "Designation: ${developer.designation}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "Tech Stack: ${developer.techStack.joinToString(", ")}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { /* Edit developer */ }) {
                                Text("Edit")
                            }
                            TextButton(onClick = { /* Delete developer */ }) {
                                Text("Delete")
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectsTab(projects: List<Project>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Manage Projects",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(projects) { project ->
                Card(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = project.name,
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = project.description,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Start: ${project.startDate}",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                text = "End: ${project.endDate}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Text(
                            text = "Status: ${project.status}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { /* Edit project */ }) {
                                Text("Edit")
                            }
                            TextButton(onClick = { /* Delete project */ }) {
                                Text("Delete")
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TasksTab() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Manage Tasks",
            style = MaterialTheme.typography.headlineMedium
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceTab() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Manage Attendance",
            style = MaterialTheme.typography.headlineMedium
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeavesTab() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Manage Leaves",
            style = MaterialTheme.typography.headlineMedium
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminProfileTab() {
    var admin by remember {
        mutableStateOf(
            Admin(
                name = "Admin User",
                email = "admin@example.com"
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Admin Profile",
            style = MaterialTheme.typography.headlineMedium
        )

        OutlinedTextField(
            value = admin.name,
            onValueChange = { },
            label = { Text("Name") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = admin.email,
            onValueChange = { },
            label = { Text("Email") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = { /* Update profile */ },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text("Update Profile")
        }
    }
}
