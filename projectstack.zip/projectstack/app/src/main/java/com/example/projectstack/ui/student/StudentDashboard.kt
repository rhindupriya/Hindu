package com.example.projectstack.ui.student

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.projectstack.model.Project
import com.example.projectstack.model.Task
import com.example.projectstack.model.Student

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentDashboard() {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Projects", "Tasks", "Profile")

    // Sample data
    val projects = remember {
        listOf(
            Project(
                name = "Android App Development",
                description = "Building a project management app",
                startDate = "01/01/2025",
                endDate = "31/03/2025"
            ),
            Project(
                name = "Web Development",
                description = "Creating a responsive website",
                startDate = "01/02/2025",
                endDate = "30/04/2025"
            )
        )
    }

    val tasks = remember {
        listOf(
            Task(
                title = "Design UI Mockups",
                description = "Create UI mockups for the app",
                deadline = "15/01/2025"
            ),
            Task(
                title = "Implement Login Screen",
                description = "Create login screen using Compose",
                deadline = "20/01/2025"
            )
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Student Dashboard") }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            TabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title) }
                    )
                }
            }

            when (selectedTab) {
                0 -> ProjectsTab(projects)
                1 -> TasksTab(tasks)
                2 -> ProfileTab()
            }
        }
    }
}

@Composable
fun ProjectsTab(projects: List<Project>) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(projects) { project ->
            ProjectCard(project)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectCard(project: Project) {
    Card(
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = project.name,
                style = MaterialTheme.typography.titleLarge
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = project.description,
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Start: ${project.startDate}",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    text = "End: ${project.endDate}",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Status: ${project.status}",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
fun TasksTab(tasks: List<Task>) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(tasks) { task ->
            TaskCard(task)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskCard(task: Task) {
    Card(
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = task.title,
                style = MaterialTheme.typography.titleLarge
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = task.description,
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Deadline: ${task.deadline}",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    text = "Status: ${task.status}",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileTab() {
    var student by remember {
        mutableStateOf(
            Student(
                registrationNumber = "12345",
                name = "John Doe",
                email = "john.doe@example.com",
                mobileNumber = "1234567890",
                mentorName = "Jane Smith",
                mentorMobile = "0987654321",
                batch = "2024",
                department = "Computer Science"
            )
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Profile",
                style = MaterialTheme.typography.headlineMedium
            )
        }

        item {
            OutlinedTextField(
                value = student.registrationNumber,
                onValueChange = { },
                label = { Text("Register Number") },
                modifier = Modifier.fillMaxWidth(),
                enabled = false
            )
        }

        item {
            OutlinedTextField(
                value = student.name,
                onValueChange = { },
                label = { Text("Name") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = student.email,
                onValueChange = { },
                label = { Text("Email") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = student.mobileNumber,
                onValueChange = { },
                label = { Text("Mobile Number") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = student.mentorName,
                onValueChange = { },
                label = { Text("Mentor Name") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = student.mentorMobile,
                onValueChange = { },
                label = { Text("Mentor Mobile") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = student.batch,
                onValueChange = { },
                label = { Text("Batch/Year") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = student.department,
                onValueChange = { },
                label = { Text("Department") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Button(
                onClick = { /* Update profile */ },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Text("Update Profile")
            }
        }
    }
}
