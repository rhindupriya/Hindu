package com.example.projectstack.model

data class Attendance(
    val student: Student,
    val date: String = "",
    val isPresent: Boolean = false,
    val batch: String = "",
    val markedBy: Developer? = null
)
